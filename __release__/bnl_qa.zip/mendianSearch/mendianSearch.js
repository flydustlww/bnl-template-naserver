webpackJsonp([3],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _mendianSearch = __webpack_require__(99);

	var _mendianSearch2 = _interopRequireDefault(_mendianSearch);

	var _vue = __webpack_require__(14);

	var _vue2 = _interopRequireDefault(_vue);

	var _search = __webpack_require__(123);

	var _search2 = _interopRequireDefault(_search);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var util = __webpack_require__(1);
	var dealIdText = void 0;
	var addCodeBtn = void 0;
	var curProduct = 1;
	var isAjaxLocked = false;

	var vm = new _vue2.default({
	    el: '#app',
	    render: function render(h) {
	        return h(_search2.default);
	    }
	});

	util.ready(function () {
	    BNJS.ui.hideLoadingPage();
	    BNJS.ui.title.setTitle('门店查询');
	});

/***/ }),

/***/ 60:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _zepto = __webpack_require__(2);

	var _zepto2 = _interopRequireDefault(_zepto);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var api = __webpack_require__(4);
	var server = __webpack_require__(9).server;
	var merchantlogin = encodeURIComponent(server + '/naserver/newapp/merchantlogintpl');
	var Baidu = __webpack_require__(16);
	var httpBnjs = __webpack_require__(6);
	var dialog = __webpack_require__(15);
	var util = __webpack_require__(1);
	var utilBNJS = __webpack_require__(3);
	exports.default = {
	    name: 'mendian-search',
	    data: function data() {
	        return {
	            items: [],
	            isShowLists: false,
	            mendianInfo: '',
	            isShowNote: true,
	            isShowTps: false,
	            isPink: false,
	            lastItem: true,
	            token: ""
	        };
	    },
	    mounted: function mounted() {
	        var wrapper = document.getElementById('wrapper');
	        var input = document.getElementById('input');
	        var selectWrap = document.getElementById('select-wrap');

	        wrapper.addEventListener('touchmove', function (e) {
	            input.blur();
	        }, false);
	        input.addEventListener('blur', function (e) {
	            selectWrap.style.position = 'fixed';
	            selectWrap.style.top = '0px';
	        }, false);
	        input.addEventListener('focus', function (e) {
	            selectWrap.style.position = 'absolute';
	            selectWrap.style.top = '0px';
	        }, false);
	    },
	    watch: {
	        mendianInfo: function mendianInfo(val, oldVal) {
	            var that = this;
	            util.ready(function () {
	                var params = function params() {
	                    var _params = {};
	                    if (/^[0-9]*$/.test(that.mendianInfo)) {
	                        _params = {
	                            merchant_id: that.mendianInfo
	                        };
	                    } else {
	                        _params = {
	                            name: that.mendianInfo
	                        };
	                    }
	                    return _params;
	                };

	                if (val === '') {
	                    that.isShowNote = true;
	                    that.isShowTps = false;
	                    that.isPink = false;
	                    that.isShowLists = false;
	                    that.items = [];
	                    return;
	                } else {
	                    that.isShowLists = true;
	                    that.isShowNote = false;
	                    httpBnjs.get({
	                        url: api.searchmerchant,
	                        params: params()
	                    }).then(function (data) {
	                        var res = data.data;
	                        if (res.length === 0) {
	                            that.isShowLists = false;
	                            that.isShowTps = true;
	                            that.items = res;
	                        } else {
	                            that.isShowTps = false;
	                            that.isShowLists = true;
	                            that.items = res.slice(0, 20);
	                        }
	                        if (errno === 2002) {
	                            BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	                        }
	                    }, function (res) {
	                        _zepto2.default.dialog({
	                            showTitle: false,
	                            contentHtml: res.msg || '出错了!',
	                            buttonClass: {
	                                ok: 'dialog-font-color-pink'
	                            }
	                        });
	                    });
	                    that.isPink = true;
	                }
	            });
	        }
	    },
	    methods: {
	        clear: function clear() {
	            this.mendianInfo = '';
	            this.items = [];
	        },
	        bindMaterial: function bindMaterial(name, merchart_id) {
	            var _this = this;
	            util.ready(function () {
	                BNJS.hardware.scanQRCode(function (res) {
	                    var url = res.data.content;
	                    var result = util.parseQueryString(url);
	                    var code_id = result.id;
	                    httpBnjs.post({
	                        url: api.bindcode,
	                        params: {
	                            code_id: code_id,
	                            product: 5
	                        }
	                    }).then(function (resp) {
	                        if (resp.errno === 2002) {
	                            _zepto2.default.dialog({
	                                showTitle: false,
	                                contentHtml: resp.msg,
	                                buttonClass: {
	                                    ok: 'dialog-font-color-pink'
	                                },
	                                onClickOk: function onClickOk() {
	                                    BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	                                }
	                            });
	                        } else {
	                            _zepto2.default.dialog({
	                                showTitle: false,
	                                contentHtml: resp.msg,
	                                buttonClass: {
	                                    ok: 'dialog-font-color-pink'
	                                },
	                                onClickOk: function onClickOk() {}
	                            });
	                        }
	                    }, function (res) {
	                        BNJS.ui.showErrorPage();
	                    });
	                });
	            });
	        }
	    }
	};

/***/ }),

/***/ 99:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 107:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 121:
/***/ (function(module, exports) {

	module.exports = "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<div>\n<div class=\"select-wrap\" id=\"select-wrap\">\n    <input type=\"text\" id=\"input\" placeholder=\"请输入门店名称/门店ID\" class=\"mendian-id-text\" v-model=\"mendianInfo\" />\n    <div class=\"clearlayer\" @click=\"clear\" v-show='mendianInfo'>\n    \t<span class=\"clear\"><span class=\"clear-close\"></span></span>\n    </div>\n    \n    <span class=\"search\" :class=\"{pink:isPink}\" >搜索</span>\n</div>\n<div class=\"content-note\" v-show='isShowNote'>\n\t<span class=\"symbol\">*</span> <span class=\"text\">门店ID请咨询销售或通过糯米商家app查询</span>\n</div>\n<div class=\"mendian-lists\" id=\"wrapper\" v-show=\"isShowLists\">\n\t<div class=\"list\" v-for=\"(item,index) in items \"  v-bind:class=\"{'lastItem': (items.length-1)===index}\" @click=\"bindMaterial(item.alliance_name,item.merchant_id)\" >\n\t\t<div class=\"mendian-name\">{{item.alliance_name}}</div>\n\t\t<div class=\"mendian-id\">门店ID:{{item.merchant_id}}</div>\n\t\t<div class=\"mendian-bind\" >+立即绑定</div>\n\t</div>\n</div>\n<div class=\"tips\" v-show='isShowTps'>没有找到该门店，请先建立该门店联盟</div>\n</div>\n";

/***/ }),

/***/ 123:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_script__, __vue_template__
	var __vue_styles__ = {}
	__webpack_require__(107)
	__vue_script__ = __webpack_require__(60)
	if (Object.keys(__vue_script__).some(function (key) { return key !== "default" && key !== "__esModule" })) {
	  console.warn("[vue-loader] src\\components\\search\\index.vue: named exports in *.vue files are ignored.")}
	__vue_template__ = __webpack_require__(121)
	module.exports = __vue_script__ || {}
	if (module.exports.__esModule) module.exports = module.exports.default
	var __vue_options__ = typeof module.exports === "function" ? (module.exports.options || (module.exports.options = {})) : module.exports
	if (__vue_template__) {
	__vue_options__.template = __vue_template__
	}
	if (!__vue_options__.computed) __vue_options__.computed = {}
	Object.keys(__vue_styles__).forEach(function (key) {
	var module = __vue_styles__[key]
	__vue_options__.computed[key] = function () { return module }
	})
	if (false) {(function () {  module.hot.accept()
	  var hotAPI = require("vue-hot-reload-api")
	  hotAPI.install(require("vue"), false)
	  if (!hotAPI.compatible) return
	  var id = "_v-f3bbbbbe/index.vue"
	  if (!module.hot.data) {
	    hotAPI.createRecord(id, module.exports)
	  } else {
	    hotAPI.update(id, module.exports, __vue_template__)
	  }
	})()}

/***/ })

});