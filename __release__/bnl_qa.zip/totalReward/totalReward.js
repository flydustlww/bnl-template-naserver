webpackJsonp([9],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	__webpack_require__(2);
	__webpack_require__(42);
	__webpack_require__(106);
	var utilBNJS = __webpack_require__(3);
	var formatMoney = __webpack_require__(41);
	var api = __webpack_require__(4);
	var dialog = __webpack_require__(8);
	var Baidu = __webpack_require__(15);
	var REWARD_LIST_TPL = __webpack_require__(121);

	var totalReward = function totalReward() {
	    this.classMap = {
	        3: 'item-status-gray',
	        5: 'item-status-gray',
	        7: 'item-status-gray',
	        4: 'item-status-green',
	        6: 'item-status-pink'
	    };

	    this.rewardDetailUrl = 'BaiduNuomiMerchant://component?compid=bnl&comppage=promoteDetail';

	    this.isAjaxLocked = false;

	    this.isInit = true;

	    this.isEnableScroll = true;

	    this.bduss = '';

	    var me = this;
	    utilBNJS.ready(function () {
	        BNJS.ui.hideLoadingPage();
	        utilBNJS.storage.getItem('bnl_bduss', function (bduss) {
	            var bduss = "2ZmaENuUlFXa1hIOFhMQmxMV0Z1cXdMWjl5U1hyelU4ZEl0ZkhpM3ZiTEQ0S2haSVFBQUFBJCQAAAAAAAAAAAEAAAAoqTMGcmVubGVpODAwOQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMNTgVnDU4FZT";
	            me.bduss = bduss;
	            this.getBillList(0, 'refresh', bduss);
	        });
	    });
	};

	totalReward.prototype.getBillList = function (xid, act, bnl_bduss) {

	    var me = this;

	    if (!me.isAjaxLocked) {
	        me.isAjaxLocked = true;
	        BNJS.http.get({
	            url: api.newbilllist,
	            params: {
	                xid: xid,
	                act: act,
	                bduss: bnl_bduss
	            },
	            onSuccess: function onSuccess(res) {
	                var data = res.data;
	                if (res.errno != 0) {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: res.msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-white'
	                        }
	                    });
	                }
	                if (data.data.bill_list.length != 0) {
	                    me.renderHTML(data);
	                } else {
	                    $('#none-list-tpl').show();
	                }
	                me.isAjaxLocked = false;
	                me.isInit = false;
	                $(window).trigger('enableLoad');
	            }

	        });
	    }
	};

	totalReward.prototype.bindEvents = function () {
	    var me = this;

	    $('.content').on('scroll', function (e) {
	        isInit = false;
	        me.check();
	    });

	    $('.navigate-right').on('click', function (e) {
	        var target = $(e.target);
	        var bill_id = $(target[0]).data('billid');
	        var time = $(target[0]).data('time');
	        var commission = $(target[0]).data('commission');
	        var status = $(target[0]).data('status');
	        var status_str = $(target[0]).data('statusstr');
	        var billcycle = $(target[0]).data('billcycle');

	        if (billcycle === 1) {
	            var params = {
	                bill_id: bill_id,
	                time: time,
	                commission: commission,
	                status: status,
	                status_str: status_str
	            };
	        } else if (billcycle === 2) {
	            var params = {
	                bill_id: bill_id,
	                time: time.split('-')[0],
	                commission: commission,
	                status: status,
	                status_str: status_str
	            };
	        } else {
	            var params = {
	                bill_id: bill_id,
	                time: time
	            };
	        }

	        utilBNJS.ready(function () {
	            BNJS.ui.hideLoadingPage();
	            BNJS.page.start(me.rewardDetailUrl, params, 1);
	        });
	    });
	};
	totalReward.prototype.check = function () {
	    var me = this;
	    if (me.isEnableScroll) {
	        var scrollHeight;
	        var scrollPosition;
	        var bodyHeight = $('#bill-list').height();
	        var viewHeight = window.innerHeight;
	        var scrollTop = $('.content').scrollTop();
	        if (bodyHeight - scrollTop - viewHeight < 10) {
	            me.addDiv();
	            $(window).trigger('disableLoad');
	            me.getBillList(me.getLastXid(), 'loadmore', me.bnl_bduss);
	        }
	    }

	    $(window).bind('enableLoad', function () {
	        me.isEnableScroll = true;
	    });
	    $(window).bind('disableLoad', function () {
	        me.isEnableScroll = false;
	    });
	};

	totalReward.prototype.getLastXid = function () {
	    var xid = $('#bill-list').find('li').find('a').last().attr('xid');
	    return xid;
	};

	totalReward.prototype.noMoreDiv = function () {
	    if ($('.loadingmore').length > 0) {
	        return;
	    }

	    var loadingmore = $('<div class="loadingmore" data-elems="loadingmore">加载中...</div>');
	    loadingmore.appendTo('.content');
	};

	totalReward.prototype.addDiv = function () {
	    if ($('.loadingmore').length > 0) {
	        return;
	    }
	    var loadingmore = $('<div class="loadingmore" data-elems="loadingmore">加载中...</div>');
	    loadingmore.appendTo('.content');
	};

	totalReward.prototype.renderHTML = function (res) {
	    var me = this;

	    $.each(res.data.bill_list, function (i, item) {

	        item.formatmoney = formatMoney.formatMoney(item.commission);
	        item.classname = me.classMap[item.status + ''];
	    });

	    var HTML = Baidu.template(REWARD_LIST_TPL, {
	        item: res.data.bill_list,
	        total_commission: '￥' + formatMoney.formatMoney(res.data.total_commission)
	    });

	    $('.content').html(HTML);
	    me.bindEvents();
	};

	new totalReward();

/***/ }),

/***/ 106:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 121:
/***/ (function(module, exports) {

	module.exports = "<div class=\"content-title\">\r\n    累计佣金金额\r\n    <span class=\"total-amount item-status-pink\"><%=total_commission%></span>\r\n</div>\r\n\r\n<ul class=\"table-view\" id=\"bill-list\">\r\n\t<%for(var i=0; i<item.length;i++){%>\r\n\t<li class=\"table-view-cell\">    \r\n\t        <a class=\"navigate-right\" data-xid=\"<%=item[i].xid%>\" data-commission=\"<%=item[i].commission%>\" data-time=<%=item[i].date%> data-billid= <%=item[i].bill_id%> data-status=\"<%=item[i].status%>\" data-statusstr=\"<%=item[i].status_str%>\" data-billcycle=\"<%=item[i].bill_cycle%>\" >\r\n\t        <span class=\"item-time\"><%=item[i].date%></span>\r\n\t        <span class=\"item-amount item-status-pink\">￥<%=item[i].formatmoney%></span>\r\n\t        <span class=\"item-status <%=item[i].classname%>\"><%=item[i].status_str%></span>\r\n\t    </a>\r\n\t</li>\r\n\t<%}%>\r\n</ul>\r\n"

/***/ })

});