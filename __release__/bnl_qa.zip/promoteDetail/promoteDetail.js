webpackJsonp([4],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	__webpack_require__(2);
	__webpack_require__(40);
	__webpack_require__(101);
	var utilBNJS = __webpack_require__(3);
	var api = __webpack_require__(4);
	var Baidu = __webpack_require__(16);
	var httpBnjs = __webpack_require__(6);
	var cutString = __webpack_require__(59);
	var formatMoney = __webpack_require__(39);

	var REWARD_LIST_TPL = __webpack_require__(114);
	var ERROR_TPL = __webpack_require__(113);
	var DETAIL_LIST_TPL = __webpack_require__(115);

	var promoteDetail = function promoteDetail() {
		this.curCount = 20;

		this.isAjaxLocked = false;

		this.isEnableScroll = true;

		this.isInit = true;

		this.curPageNum = 1;

		this.curUserType = 0;

		this.promoteInfoMap = {
			billing_user: '推广用户',
			rule_name: '推广策略',
			pay_time: '购买时间',
			consumption_time: '消费时间',
			deal_info: '团单名称',
			order_price: '订单金额',
			product_type: '推广类型',
			user_type: '用户类型',
			lower: '下级推广员'
		};

		this.bill_id = '';

		this.time = '';

		this.bduss = '';

		var me = this;
		utilBNJS.ready(function () {
			BNJS.ui.hideLoadingPage();
			BNJS.page.getData(function (res) {
				me.bill_id = res.data.bill_id;
				me.time = res.data.time;
				me.getBill(me.bill_id, me.curPageNum, me.curCount, me.curUserType);
			});

			me.bindTabEvents();

			me.bindArrowEvents();
		});
	};

	promoteDetail.prototype.getBill = function (bill_id, page, count, user_type) {
		var me = this;
		if (!me.isAjaxLocked) {
			me.isAjaxLocked = true;
			utilBNJS.storage.getItem('bnl_bduss', function (bduss) {
				httpBnjs.get({
					url: api.billing,
					params: {
						bill_id: bill_id,
						page: page,
						count: count || 10,
						user_type: user_type
					}
				}).then(function (res) {
					var data = res.data;
					console.log('GetPromoteInfo接口返回=' + data);
					if (data.errno === 0) {
						if (data.data && data.data.detail.length > 0) {
							me.renderTotalReward(data);

							me.removeDiv();
						} else {
							if (me.isInit) {

								$('#reward-list').addClass('table-noborder');

								me.removeDiv();

								if (me.curUserType == 0) {
									me.showError('当日无推广活动！');
								} else {
									me.showError('不存在该种类型的推广记录！');
								}
							} else {
								me.noMoreDiv();
							}
						}
					} else {
						me.showError(data.msg);
					}
					me.curPageNum += 1;
					me.isAjaxLocked = false;
					$(window).trigger('enableLoad');
				});
			});
		}
	};

	promoteDetail.prototype.bindTabEvents = function () {
		var me = this;

		$('.control-item').on('click', function (evt) {
			me.isInit = true;

			me.curPageNum = 1;

			var target = $(evt.target);

			me.curUserType = target.attr('user_type');

			me.getBill(me.bill_id, me.curPageNum, me.curCount, me.curUserType);

			evt.preventDefault();
		});

		$('.content').on('scroll', function (e) {
			me.isInit = false;

			me.check();
		});
	};
	promoteDetail.prototype.bindArrowEvents = function () {
		var me = this;

		$('.reward-list').on('click', function (evt) {

			var li = $(evt.target).closest('li');

			var target = li.find('.icon');

			var id = target.attr('id');

			if (target.attr('status') == 'down') {

				me.getPromoteInfo(id, target);

				target.removeClass('icon-down').addClass('icon-up');

				target.attr('status', 'up');

				return;
			}

			if (target.attr('status') == 'up') {

				target.parent().find('.order-detail-list').hide();

				target.removeClass('icon-up').addClass('icon-down');

				target.attr('status', 'down');

				return;
			}

			evt.preventDefault();
		});
	};

	promoteDetail.prototype.formatTime = function (time) {

		var time = time * 1000;

		var formattime = {};

		var date = new Date(time);

		formattime.year = date.getFullYear();

		formattime.month = date.getMonth() + 1 < 10 ? '0' + parseFloat(date.getMonth() + 1) : date.getMonth() + 1;

		formattime.date = date.getDate() < 10 ? '0' + parseFloat(date.getDate()) : date.getDate();

		formattime.hour = date.getHours() < 10 ? '0' + parseFloat(date.getHours()) : date.getHours();

		formattime.minute = date.getMinutes() < 10 ? '0' + parseFloat(date.getMinutes()) : date.getMinutes();

		formattime.second = date.getSeconds() < 10 ? '0' + parseFloat(date.getSeconds()) : date.getSeconds();

		return formattime;
	};

	promoteDetail.prototype.getPromoteInfo = function (bill_id, target) {

		var me = this;
		BNJS.http.get({
			url: api.GetPromoteInfo,
			params: {
				billing_id: me.bill_id,
				bduss: me.bduss
			},
			onSuccess: function onSuccess(res) {
				var data = res.data;
				var arr = me.dealDetailData(data);

				me.renderPromoteDetailList(arr, target);
			}
		});
	};

	promoteDetail.prototype.dealDetailData = function (data) {
		var arr = [];
		var me = this;
		$.each(data.data, function (key, value) {
			if (me.promoteInfoMap[key]) {
				if (key == 'pay_time' || key == 'consumption_time') {
					value = me.formatTime(parseFloat(value)).year + '-' + me.formatTime(parseFloat(value)).month + '-' + me.formatTime(parseFloat(value)).date + ' ' + me.formatTime(parseFloat(value)).hour + ':' + me.formatTime(parseFloat(value)).minute + ':' + me.formatTime(parseFloat(value)).second;
				}

				if (key == 'order_price') {
					value = '￥' + formatMoney.formatMoney(value);
				}

				if (key == 'user_type') {
					if (value == '1') {
						value = '新用户';
					}

					if (value == '2') {
						value = '老用户';
					}
				}

				if (key == 'product_type') {
					switch (value) {
						case '1':
							value = '常规地推';
							break;
						case '2':
							value = '储值卡推广';
							break;
						case '3':
							value = '到店付';
							break;
						default:
							value = '--';
					}
				}

				if (key == 'rule_name') {
					if (value == '') {
						value = '--';
					} else {
						value = cutString.cutString(value, 18);
					}
				}

				if (key == 'deal_info') {
					value = cutString.cutString(value, 18);
				}

				var json = {};
				json.label = me.promoteInfoMap[key];
				json.content = value;
				arr.push(json);
			}
		});
		return arr;
	};

	promoteDetail.prototype.renderPromoteDetailList = function (arr, target) {
		var html = Baidu.template(DETAIL_LIST_TPL, {
			formatdata: arr
		});

		var $deliatList = target.parent().find('.order-detail-list');
		$deliatList.html(html);
		$deliatList.show();
	};

	promoteDetail.prototype.check = function () {
		var me = this;
		if (me.isEnableScroll) {
			var scrollHeight;
			var scrollPosition;
			var bodyHeight = $('.reward-list').height();
			var viewHeight = window.innerHeight;
			var scrollTop = $('.content').scrollTop();
			if (bodyHeight - scrollTop - viewHeight < 10) {
				me.addDiv();
				$(window).trigger('disableLoad');
				me.getBill(me.bill_id, me.curPageNum, me.curCount, me.curUserType);
			}
		}

		$(window).bind('enableLoad', function () {
			me.isEnableScroll = true;
		});
		$(window).bind('disableLoad', function () {
			me.isEnableScroll = false;
		});
	};

	promoteDetail.prototype.removeDiv = function () {
		$('.loadingmore').remove();
	};

	promoteDetail.prototype.addDiv = function () {
		if ($('.loadingmore').length > 0) {
			return;
		}

		var loadingmore = $('<div class="loadingmore" data-elems="loadingmore">加载中...</div>');
		loadingmore.appendTo('.content');
	};

	promoteDetail.prototype.noMoreDiv = function () {
		if ($('.loadingmore').length > 0) {
			$('.loadingmore').html('没有更多了');
		}

		$('.loadingmore').prev().find('.collapse').remove();
	};

	promoteDetail.prototype.showError = function (msg) {
		var html = Baidu.template(ERROR_TPL, {
			msg: msg
		});

		$('.content').append(html);
	};

	promoteDetail.prototype.renderTotalReward = function (data) {
		var me = this;
		$.each(data.data.detail, function (index, item) {
			if (item.commission) {
				item.formatcommission = formatMoney.formatMoney(item.commission);
			}
		});
		var html = Baidu.template(REWARD_LIST_TPL, {
			totalamount: '￥' + formatMoney.formatMoney(data.data.total_commission),
			curday: me.time,
			detail: data.data.detail
		});
		$('.reward-list').html(html);
		$('.loadingmore').remove();
	};

	new promoteDetail();

/***/ }),

/***/ 101:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 113:
/***/ (function(module, exports) {

	module.exports = "   <ul class=\"table-view table-none-view\">\r\n        <li class=\"none-text-list\">\r\n            <div class=\"table-none-view-img\"></div>\r\n            <p class=\"none-text\"><%=msg%></p>\r\n        </li>\r\n    </ul>"

/***/ }),

/***/ 114:
/***/ (function(module, exports) {

	module.exports = "\r\n    <ul class=\"table-view table-view-tpl\" id=\"reward-title-html\">\r\n        <li class=\"table-view-cell\">\r\n            <span class=\"font-color-gray\"><%=curday%></span>\r\n            <span class=\"font-color-gray item-label\">总计</span>\r\n            <span class=\"item-amount item-status-pink item-totalamount\"><%=totalamount%></span>\r\n        </li>              \r\n    </ul>\r\n    <ul class=\"table-view\" id=\"reward-content-list\">\r\n        <%for(var i=0; i<detail.length;i++){%>\r\n            <li class=\"table-view-cell\" id=<%=detail[i].id %> >\r\n                <% if (detail[i].finance_type === '1')  {%>\r\n                    推广佣金\r\n                <%}else if (detail[i].finance_type === '2') {%>\r\n                    下级提成\r\n                <%}else {%>\r\n                    作弊扣减\r\n                <%}%>\r\n\r\n                <span class=\"icon icon-down\" status=\"down\" id=<%=detail[i].id%> ></span>\r\n                <%if (detail[i].commission >=0) {%>\r\n                    <span class=\"item-amount item-status-pink\">+<%=detail[i].formatcommission %></span> \r\n                <%}else {%>\r\n                    <span class=\"item-amount item-status-green\"><%=detail[i].formatcommission%></span>\r\n                <%}%>\r\n                <ul class=\"table-view order-detail-list\"></ul>\r\n            </li>\r\n        <%}%>\r\n    </ul>\r\n\r\n\r\n\r\n\r\n"

/***/ }),

/***/ 115:
/***/ (function(module, exports) {

	module.exports = "<%for (var i = 0; i < formatdata.length; i++) {%>\r\n    <li class=\"table-view-cell order-detail-item\">\r\n        <span class=\"font-color-gray order-detail-label\"><%=formatdata[i].label%></span>\r\n        <span class=\"order-detail-content\"><%=formatdata[i].content%></span>\r\n    </li>\r\n<%}%>"

/***/ })

});