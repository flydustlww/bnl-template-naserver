webpackJsonp([1],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _vue = __webpack_require__(14);

	var _vue2 = _interopRequireDefault(_vue);

	var _unionCenter = __webpack_require__(124);

	var _unionCenter2 = _interopRequireDefault(_unionCenter);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var util = __webpack_require__(1);


	var vm = new _vue2.default({
	    el: '#app',
	    render: function render(h) {
	        return h(_unionCenter2.default);
	    }
	});

	util.ready(function () {
	    BNJS.ui.hideLoadingPage();
	    BNJS.ui.title.setTitle('百度糯米商户联盟');
	    BNJS.ui.title.addActionButton({
	        tag: '2',
	        text: '帮助',
	        callback: function callback() {
	            BNJS.page.start("BaiduNuomiMerchant://component?compid=bnl&comppage=help", {});
	        }
	    });
	    BNJS.page.reShow(function () {
	        BNJS.page.start('BaiduNuomiMerchant://component?compid=bnl&comppage=unionCenter', {}, 1);
	    });

	    BNJS.page.registerReceiver('com.nuomi.merchant.broadcast.PERSONALPROFILE', function (res) {
	        BNJS.page.start('baidunuomimerchant://component?compid=bnl&comppage=userCenter', {});
	    });
	});

/***/ }),

/***/ 60:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _stringify = __webpack_require__(61);

	var _stringify2 = _interopRequireDefault(_stringify);

	var _zepto = __webpack_require__(2);

	var _zepto2 = _interopRequireDefault(_zepto);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	__webpack_require__(24);
	__webpack_require__(103);

	var api = __webpack_require__(4);
	var server = __webpack_require__(9).server;
	var merchantlogin = encodeURIComponent(server + '/naserver/newapp/merchantlogintpl');
	var FastClick = __webpack_require__(37);
	var Promise = __webpack_require__(40).Promise;
	var Baidu = __webpack_require__(16);
	var dialog = __webpack_require__(15);
	var util = __webpack_require__(1);
	var utilBNJS = __webpack_require__(3);
	var httpBnjs = __webpack_require__(8);

	FastClick.attach(document.body, {});
	exports.default = {
	    name: 'union-center',
	    data: function data() {
	        return {
	            isLogin: false,
	            is_alliance: false,
	            isInfo: false,
	            is_new: 0,
	            is_verified: '',
	            new_num: 1,
	            total_amount: '',
	            merchant_name: '',
	            passport_username: "",
	            promote_count: '',
	            today_commission: "---",
	            total_commission: "---",
	            alliance_name: "",
	            uid: 0,
	            curTime: ''
	        };
	    },
	    created: function created() {
	        var _this = this;
	        util.ready(function () {
	            _this.getData();
	        });
	    },
	    methods: {
	        getData: function getData() {
	            var that = this;
	            this.uid = typeof BNJS.account.uid === "number" ? BNJS.account.uid : 0;

	            var curTimeDate = new Date();
	            this.curTime = curTimeDate.getTime();
	            httpBnjs.get({
	                url: api.checkuserinfo,
	                params: {
	                    b_uid: that.uid
	                }
	            }).then(function (res) {
	                return that.checkuserInfoOk(res);
	            }, function (res) {
	                console.log((0, _stringify2.default)(res));
	                BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	            }).then(function (res) {
	                that.myuserInfoOk(res);
	            }, function (res) {
	                BNJS.ui.showErrorPage();
	            });
	        },
	        checkuserInfoOk: function checkuserInfoOk(res) {
	            console.log("登录的数据");
	            console.log(res);
	            var that = this;

	            switch (res.errno) {
	                case 0:
	                    {
	                        if (res.data.is_new === 1) {
	                            that.is_new = 1;
	                            that.firstUniondialog(res.data);
	                        }
	                        if (res.data.alliance_info.alliance_name) {
	                            that.is_alliance = true;
	                        }

	                        return httpBnjs.get({
	                            url: api.myuserinfo,
	                            params: {
	                                b_uid: that.uid
	                            }
	                        });
	                        break;
	                    }

	                case 2002:
	                    {
	                        that.isLogin = false;
	                        that.forceLogin();
	                        break;
	                    }

	                case 70150:
	                    {
	                        that.is_alliance = false;
	                        that.isInfo = true;
	                        that.isLogin = true;
	                        BNJS.localStorage.getItem('bnl_allianceFlag', function (res) {
	                            console.log("拿到storage返回值==");
	                            console.log(res);
	                            if (res.data == "") {
	                                that.addUniondialog();
	                                BNJS.localStorage.setItem('bnl_allianceFlag', {
	                                    name: "ok",
	                                    time: that.curTime
	                                }, function () {
	                                    console.log("成功添加storage");
	                                }, function () {
	                                    console.log('添加失败');
	                                });
	                            } else {
	                                if (new Date().getTime() - res.data.time > 30000) {
	                                    BNJS.localStorage.removeItem('bnl_allianceFlag', function () {}, function () {});
	                                }
	                            }
	                        }, function (res) {
	                            BNJS.ui.hideLoadingPage();
	                            that.addUniondialog();
	                            BNJS.localStorage.setItem('bnl_allianceFlag', {
	                                "name": "ok",
	                                "time": that.curTime
	                            }, function () {}, function () {});
	                        }, '2.7');

	                        that.changeInfo({
	                            info: "您尚未填写角色，故无法加入联盟",
	                            linkInfo: "去填写角色",
	                            url: "BaiduNuomiMerchant://bindingphone?channel=alliance&notificationName=com.nuomi.merchant.broadcast.PERSONALPROFILE&bottomText=填写完成,去退出重新登录"
	                        });
	                        return httpBnjs.get({
	                            url: api.myuserinfo,
	                            params: {
	                                b_uid: that.uid
	                            }
	                        });
	                        break;
	                    }
	                case 1004:
	                    {
	                        BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	                        break;
	                    }
	                case 2001:
	                    {
	                        BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	                        break;
	                    }
	                default:
	                    {
	                        BNJS.ui.showErrorPage();
	                    }
	            }
	        },
	        myuserInfoOk: function myuserInfoOk(res) {
	            if (res) {
	                console.log("用户的数据");
	                console.log(res);
	                var datas = util.cloneObj(res.data);
	                var that = this;
	                switch (res.errno) {
	                    case 0:
	                        {
	                            that.isLogin = true;

	                            (0, _zepto2.default)('.union-user').on('click', function () {
	                                var url = "BaiduNuomiMerchant://component?compid=bnl&comppage=userCenter";
	                                BNJS.page.start(url, {});
	                            });
	                            if (res.data.alliance_name === "") {
	                                that.alliance_name = "未加入联盟";
	                                that.passport_username = datas.passport_username;
	                            } else {
	                                that.is_verified = datas.is_verified;
	                                that.alliance_name = datas.alliance_name;
	                                that.merchant_name = datas.merchant_name;
	                                that.passport_username = datas.passport_username;
	                                that.today_commission = datas.today_commission;
	                                that.total_commission = datas.total_commission;
	                                (0, _zepto2.default)('.today').on('click', function () {
	                                    var url = "BaiduNuomiMerchant://component?compid=bnl&comppage=dailyBilling";
	                                    BNJS.page.start(url, {});
	                                });
	                                (0, _zepto2.default)('.total').on('click', function () {
	                                    var url = "BaiduNuomiMerchant://component?compid=bnl&comppage=totalReward";
	                                    BNJS.page.start(url, {});
	                                });
	                            }

	                            if (that.is_verified === 0) {
	                                that.isInfo = true;
	                                var verifiedUrl = encodeURIComponent("https://m.baifubao.com/wap/0/wallet/0/cardlist/0");
	                                that.changeInfo({
	                                    info: "您尚未实名认证，将无法进行佣金结算",
	                                    linkInfo: "立即认证",
	                                    url: "BaiduNuomiMerchant://component?url=" + verifiedUrl
	                                });
	                            }

	                            break;
	                        }
	                    case 2002:
	                        {
	                            that.isLogin = false;
	                            that.forceLogin();
	                            break;
	                        }
	                    default:
	                        BNJS.ui.showErrorPage();
	                }
	            } else {
	                return;
	            }
	        },
	        forceLogin: function forceLogin() {
	            (0, _zepto2.default)('.union-top').on('click', function () {
	                BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	            });
	            (0, _zepto2.default)('.union-list').on('click', function () {
	                BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	            });
	        },
	        changeInfo: function changeInfo(data) {
	            var info = data.info;
	            var linkInfo = data.linkInfo;
	            var url = data.url;
	            (0, _zepto2.default)('.union-info').html(info);
	            (0, _zepto2.default)('.union-info-link').html(linkInfo + "&nbsp;>");
	            (0, _zepto2.default)('.union-info-wrap').on('tap', function (ev) {
	                BNJS.page.start(url, {});
	            });
	        },
	        materialClick: function materialClick() {
	            if (this.is_alliance) {
	                BNJS.page.start("BaiduNuomiMerchant://component?compid=bnl&comppage=myMaterial", {});
	            }
	        },
	        baiduWalletclick: function baiduWalletclick() {
	            if (this.is_alliance) {
	                var _url = encodeURIComponent("https://m.baifubao.com/?from=singlemessage&isappinstalled=1");
	                BNJS.page.start("BaiduNuomiMerchant://component?url=" + _url, {});
	            }
	        },
	        myMessageclick: function myMessageclick() {
	            if (this.is_alliance) {
	                BNJS.page.start("BaiduNuomiMerchant://mymessagedetail?typeName=公告&typeId=1", {});
	            }
	        },
	        firstUniondialog: function firstUniondialog(data) {
	            var name = data.alliance_info.alliance_name || "";
	            var num = data.new_num || 0;
	            if (num > 0) {
	                _zepto2.default.dialog({
	                    showTitle: false,
	                    dialogClass: 'firstUnion',
	                    contentHtml: '恭喜您加入<br><span>' + name + '</span><br>成为百度糯米商户联盟第' + num + '位会员',
	                    buttonClass: {
	                        ok: 'dialog-font-color-white'
	                    },
	                    buttonText: {
	                        ok: '我知道了'
	                    }
	                });
	            } else {
	                _zepto2.default.dialog({
	                    showTitle: false,
	                    dialogClass: 'firstUnion',
	                    contentHtml: '恭喜您加入<br><span>' + name + '</span><br>',
	                    buttonClass: {
	                        ok: 'dialog-font-color-white'
	                    }
	                });
	            }
	        },
	        addVertifydialog: function addVertifydialog(data) {
	            _zepto2.default.dialog({
	                type: 'confirm',
	                showTitle: false,
	                contentHtml: "您尚未实名认证!<br>将无法进行佣金结算",
	                buttonText: {
	                    ok: '立即认证',
	                    cancel: '稍后再说'
	                },
	                buttonClass: {
	                    ok: 'dialog-font-color-blue',
	                    cancel: 'dialog-btn-cancel'
	                },
	                onClickOk: function onClickOk() {
	                    window.location.href = encodeURIComponent("https://m.baifubao.com/wap/0/wallet/0/cardlist/0");
	                    BNJS.page.start("BaiduNuomiMerchant://component?url=" + url, {});
	                },
	                onClickCancel: function onClickCancel() {
	                    console.log("error");
	                }
	            });
	        },
	        addUniondialog: function addUniondialog(data) {
	            _zepto2.default.dialog({
	                type: 'confirm',
	                showTitle: false,
	                dialogClass: 'addUnion',
	                contentHtml: "<p>您尚未加入联盟!</p>系统检测您登录的手机号尚未填<br>写角色信息，故无法加入联盟认<br>领物料和推广，请您尽快完善。",
	                buttonText: {
	                    ok: '立即填写',
	                    cancel: '稍后处理'
	                },
	                buttonClass: {
	                    ok: 'dialog-font-color-blue',
	                    cancel: 'dialog-btn-cancel'
	                },
	                onClickOk: function onClickOk() {
	                    BNJS.page.start('BaiduNuomiMerchant://bindingphone?channel=alliance&notificationName=com.nuomi.merchant.broadcast.PERSONALPROFILE&bottomText=填写完成,去退出重新登录', {});
	                },
	                onClickCancel: function onClickCancel() {}
	            });
	        }
	    }
	};

/***/ }),

/***/ 61:
/***/ (function(module, exports, __webpack_require__) {

	module.exports = { "default": __webpack_require__(64), __esModule: true };

/***/ }),

/***/ 64:
/***/ (function(module, exports, __webpack_require__) {

	var core  = __webpack_require__(18)
	  , $JSON = core.JSON || (core.JSON = {stringify: JSON.stringify});
	module.exports = function stringify(it){ // eslint-disable-line no-unused-vars
	  return $JSON.stringify.apply($JSON, arguments);
	};

/***/ }),

/***/ 103:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 120:
/***/ (function(module, exports) {

	module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHIAAAByCAYAAACP3YV9AAAABGdBTUEAALGPC/xhBQAAEepJREFUeAHtnAusFNUZx0FFfFGrVnzUEkAQrSU0sfWJFtFqjaVIadNqkVa0QqpWsE1fkahpmqZFEm0krTE2Wo001hZRmrTGwtUI2hqqqGkF9F5DRNSKL4gvwNvff5m9fnw7uzOzO2d29sKX/HfOOXPO9/3Pd2Znzmtm4IAOld7e3t2hPhKMMRhGeEgMSBqwKQbrSFtt0D1w4MBtxDtOBnYKYxruILhOAKeDLwA14CCQp2xBmRr2IbAMdNGwGzmWXkrdkDTeeDw4BUwE40DRfHuxuQosBYto1Ec4llKKdkyiE2i8UWS6EEwDunWWSbohcye4g0Z9rkzEStGQNN4eOOUCMBOcnMFBL5HXPuPWEn8D+OehVPpn5wGkjQb2GXu4MqaUFeS7GdxFo25NWaZ/ZqMBB4OZoAckyTYyrATzwDngY3l7RToj3bIhW7KZJN1kUB0G582n9Pqo9D5gDlgPGsk7nFwIpgD9gwoV2Yxsi4O4NBLVRXXap1CS7TJGRSeDF0A9+ZATXWAGyP1f12y9xSXiJG7iWE9Ut8nN2il9OSo3AiypV3vS3wULwIiyV0YcI67iXE9U19LXJbWvqcweYC6oV+nNnLseHJZaaUkyinPEXXWIE92OVXd15jpXqMAwsALEyQckqlOhgX5Hi+oQ1UV1ihP5QLNOnScQnwQ2xtWKND1nju28WjVmrDpFdeNQI/LFpMYaSnQWsoOAbpVx8jKJGuz3a1EdgeoaJ/JN3lOL+foTgkPAg3HsSbsPHJivxfJqU12jOnOoEflIExTlE4gNBStrKPf26rlxVfkYF8NIdQdxz075amgxLFJagZC642uBF42pTkippt9mkw+AfOFFPivHEAUiY8EGz5C4emo7za006SrEF+rZPgq8yHdjk8oHPQ+BkSCuEf9K+s4xVZXBw/IJkG+8yIctrfQ0vfqBYd3flwMtO1n5A5GL27UiAC/NyR4FxG8/oMG4VkPeAlp6ehFuWmdsi8BPfG4F0x0BcTsFbq+69HBRyKh3GtexuYH0pi+OZhhjby9wLrgFJE3Ck6VXszD3g0vAIc3YbLUMdgcC+cqLfFpMbxZDGifGDTFuJ72wRsSWOhD3gHrTY5xKFC1TLQffAbu12kBZymNPjSmfeZFvw48zMTLfWyau+34h84nYGQ3+BPKWp1F4bpbGaDUv9jQPHffMnN+q7oblMToJeFHvNHjHBht7g5vAFtBINGZbBx4DfwELgaYE14BNIEmUV7sGChFsqQMUNx89KQgBjGkCfCOworFR8CEGNo4Aen7Ukx5O6JkzAWibZF3h/NHgx+BRUG9d8U3OnV1XSc4nsKVZIPnSinyd70Q7CnUL8FeNrvzgg31snAjihjgkV55vpzbrV8p/CqiTtBV4UdqcZnVnLYctPfP9DJB8nt8jC2VaU/MSfNoNg+qNvucNE18NpmR1Vr386DoGaC44Tn5Tr1ze6RjXdJ6XubnYQesI8K7Tfl8uyhsowZ6WhN52dhVVRyfIMxm9l4G4Z/DlDajmegr7/oKS71ufxkPJEmBFyzNBn4vo13TW89YoYT3PrgFBhzjonwh8X0CNe2auLVZHGXYOBPKxlSV1sqdLRtN5VlsUnpaudHO5sLE7WBbZsoeZzWnMXgqjutW+YY0Tfh0cmV1b9hLYmeZsK9rchi4Kqlvse1Jd2WllK4HNS4GXG7NpaT03BM4CvhPU2j8jAy1sdzknqC2yP1IopD2aVtSjCro9A/26eF6yRgk/ABoOKTL4J1NW7F7puCiqF4iCC3bUR/C92Gy9aBQMBn7ecl5o9ti8GljR9Ftb5kOrdcX+Pywhwv+sngt9xNY8Z1ttkn5HO5lnOQVyaNDdbtIP3nJ2rw3trCT98DkO+ImDqUnl8jiPXflEvrcyK5VuSmjw321LEi7i36jVCCuvENEyVNsFHprms3J/UaQw6jeyqW2SJwnINN0yJqxxzKGhiWPDD3N+GtpmWv1w+zSwIp/sm7Z8K/mwcyjw43i/lllrgkJa1rGyoDZXvikY2xd4soVNXKepDfyetU4h/NU05fLIg60FzrYW9OsLmUe5Ano2tD6rUN9k5Qw2pjq7zyYUKfw0/H7lON5eFAnsanZNbWFllLXvF1P95uGH2XrQYwsECp/m9N7r4mWILnYkChmGyGbUBg87+76tPjpNc/tpsRkfnQ0Xwu7f7KVG+Pxw1prTDCfd/q3oH7J3c9qyl8KWXjO08nysFnKMt7kI602iQt5PxM5aZ7uwqz3WGXUS4eiHR8fUyZp7stoC+Jdtx1cN2VurXxZazF/67WrGwEd/wWwIbK9Z9fpmgZX9bSRkOGoLf3vvazPbkBMdkbtdPGTUjxdfDmmsBd2el+fdgupURX2b9LVZpSH5y2rWZpxR9SHhLhMPHdSHiqwUMkazBlOGfcN9kLJcXtm6UKS2qcq4qO0GVP+REzhj1/me5K/8RjV3AcdNzkaWz6S4okGj/q1qzzuo8ahNnjRG1GYTFK825OmKGFlqwkUE/S2rdA3JlS9f+RmuV4pwjrPh26bSdtWG9L1En9npyj26xmkc5uJliOrisstpm/mH+M5PETx921TabjeuNE3A+umwxlNA+dNd5VSe5eJliHpOT7WJlG+bMZU25Ec7t62sL5ogxv2ktMZL2VfDAxKHz2LrJMJtm9THtl8rHq1bq/83rg7oj1jV3KL+wwm9jVQVzZj4f0D1XOFHHKeL6ovOcDunEX0bjSlFQ0YO8o652DmundELMG6n49Zy8f23jYRK3ZCLnGO+zD/hVJdWeBQOasBrnWHP1Z0OHo1tSN9D1KcyCxeu8BUY7XKGf+3i7YjOxugnjeF3CN9g4u0I+jYaNoArTu8XWDmpHcxkExLHWyJReHob+QyDg17osfLzdvGp2oXMSZYQ4RVy3lMusa0fJoDL3Y6PerDHVStR1BGbWrZ60nF5lXgxbxQ3qCgcxjpeT6khe1zi8AY6gp+Ci3Yp+G0fL5J2WHDjkQFs6W3iPwMv3yuKQyM7kBruiPWoIV9ziZpAb6vA53zHSdEngH1WBeGIjT3Ab4GXu4IYbEIpxLRN0sprasj3bQrhPZvQnXsRePzC8VJUu9CPz91YpBDdeoHmQeDlcRLs8CMUhVR64bKnI/h+mRtSt7d7HWFFddu9FFTniVNVPikT+j4P/E4FkioXT6km8eEU25Clu7VWnQ7hfcA9IE5Wkfilat5mj+g4EvwR+F1qJPU+B45pVneocnCKvbX2cMLK8FAEmtELMf0zrwNxjhbvLnARODitfvLq3ZZzwK3AvyhDUkX0zkfQ90DT8vX54DV8O8W+3x6tfPjF0bZ3ry1xJgp6iV8D5Wc43gb8ZLqWcQQ1tFYGtMzzIngfrAOvAvV4dXsUPgf0T25UT23Kno3trRzLKJ77Jj0j/c7yk8vIXJzgegT4PdgGQshjKD2trPWv8oLjya7yy9Vh8P/IA6oFynbkH6LvyM2A11dAnpPWmvL6OrpPBA+Xrd4xfHwbbdKtVbcfK6NtpCxhrkBtmbwCfAvk0QFRvRcDrbpoR31Zb6PQqxHfRuvUkKtdNr8+6U4XG6UBtaPu++CHIEvnQw3zZgTddRTW7my9V7KUhnuCY6eKb6PVpW1IGlAD8MvAj0CjHqk6Q48DdXJ0Ua7RkYbayLG/Sk1DqgPR9q0e3ttwOho8A+qJPqKkj/FpYkA90p1KqHPNVg81pOYW/VjKb+EvzFFw+SbYBOJE37/5GfDd78L4tdsQddc7IFbUdtt39xF42p4hfE7RhLGpaaebHI9qVN+8mQvadoHJH9jXJMI3ivaNtRdx4NAnT/edJ8k7cF7fyQIC2N8LLANxciuJHy+ARkMTcNCHnKpvLes1wBENCwQ6id15wMpNfaZInWrPEF7ZdzJwAFvaW6vvqnrRgvJFgc2nVg+XSxxBfQnrjNQKcsqIzZWOx9Q+1ZzQJKydy9TMiR909uXPM4Cd3wEvWoUYl6edVnTBRfO9cSsjW0if1YruLGWxdQBQ21RFbXbQDjpI0MKtlSk7ZAgQwdg11mAU/jfH/QOYa0klnNS7j1urFO1Ctm5iZ4qMGakdC3Nyvsmg4MKWap5QGP1fc/YU7Qb+RZkETcWeht8PgP1XEK18s+680Eyw47/3M7/GJpnGi5ERPaOC9BLRuz/YYGwp+D9wVA2xEibA81wg/1jZTGRUKLro1rDD2xwfa4+MzwMrmqDOXTDgn4sieELuhgIqhK82UOsZaUWrJ5oty13Qm+5jELJMZi3gWunKmxHKtQRjO1ay95O87RShD96aWfISpC4Y6XKGrqtbRzKOcpnl8NzGS+gaBJ5xNhQfVJdUyU/A3W+bfIu0HXuSLdYBfSOAv/gb38YpsBxYye0TZij9rlVMWOTi7/MtVr6o4vD/BNDGZSvX52kfxdk+YSbjFJpuGRHWrrVcJqbR46cCb8mzwu3SRb2uBFbksyxLbnWpo+cwIH1Wkl+jILcm0bttKcItX2HomOh0aj/tIXVr0EEnqIc2c61z9ZudRxXQeb3Tq7ZJ16Ei4yxXWF3rlu77lF/kdN6ZR0XLooO6aXxpRZvFWhKUacZNvrcyM7VSSukKW29LE256Ip2yw4EfRHfUcCPJedTvYOCXA49LKtfoPPr8BLnaZHCjMjXnKDAHWBHJY2sypkignP9Eplb0+51QTz/5P7fZSsrXwF8YczLrQ4l2eb8ArHRlVkQBFKyxSgh/uxk9ZS9DvXxHUftsmxJ0dTmfqS38nt50uik42SlT9MJ0pbfnIr/GQFbUA9N+nH4n1Es9TCtbiWReS6XMhVZJFJ7cksNQssQpfZl46q41eX3H6e8tESp5Yeq7yvnrzCyU5VsgH1tZkqRjt6QMnL8CvGfyachwm4knBc92GR5w8f4W/Zer0GddPCl6GxnssEy+Vxu0Llwac+3lEYWvStJMPo1JNWVl5TNJ5Tr5PBW93FaWcOphFnmvcmUVvTo3f6BMDbJCWo2oR9VwCMH5U01+BdfnRqqkiqijlgNfA/LX7SDVojP5TgC+lyod6Qb/af2BwmFA2xGtqCdV93nJOY1HTwKzwULwy7T2dqZ8+EUDf/nSinw9LIgfUDzJWorCumqa6xYHYdlZSuU78GjkS3uYFLQmWPJzfzKuXd/53gKC1qIcyuWzyHccdpCW57YTa4i5QSBuE5KeBwMTFezKUPGAfAXkMy/ybTHrsxgaAlZ6BsRvALsaM+FilY/AjcCLfDokoXi+pzE4FMTt9dRVtus2W8fd8g2I+yfKl0PrFAubjOGRYAPwomfmrg6Qc798AuQbL/JhbltqnNl0UQiMBXGNqd5s3aFJOu39J5d8AeJ6p/Ld2FLUFCL6Z8bdZjU2ajhpUIoKBCYhHwA/TiSp4rORgc1nUw8pPTPjOkCarUiczstmrXNyq+7Az9iQVPFVe56JSe6D3BAQNzQR8fvATnOrVV2jOnOoEfmo2N5pUuP58xDUOHN+DfXtCVqemebL9Le46gj8UtR2D2z3TTHjxDwcC+tJYGOVvTt2EW9q20ge3ELpUJ2A6hYn8kXYabeAFdNEu3qvcaLnhjYXtbQ7LxT3LHpVh6gucc9CTlV8EGYCPAvRVvJSCQ2AtZ7pN9mSVBFt99P87aGt2GlHWXGOuPstiyRXRHVW3fvPBAmVGQH8thGS+kSVXgDaOzBOcUWIY8S13sXJ6UpdS1+XFNWNz0IFzwNxYypVXvIh0HNmBgjyfmY8s8ap4hJxEjdxrCeqW/CXXhuzLegsFdVUlfbN+k3QJO0gem9yIZgCCvmmgXWBbEa2xUFcGonqojrtfFOTVHow0C67HpAk28iwEqiDpO/d5P5vlc5It2zIlmwmSTcZVIdsO8DtFZNDuBRLTjhBnYELwEyQ5XuxL5Ff35+rQp/rfB1sBpsMCFY+tKtBuLAf0OTEaDDG4HDCaWUFGW8Gd5Xhy5KlaEjrORp1FHFtgtbEQbnmIQcM6IbTneAOGu85jqWR0jVk1TM0qLidAvSZmIlA390pmq++PLkKLAWLaLxHOJZSinZM006gYTVxMAGcDvQNc90S857q2oJO3aYfAstAV6d8LrRjGhKn7iDRc3UEifYZp9kTdYL0DKw+D3WU2GemnqFvg3Wg+nzVsacMzzt4ZJb/A5IMIfk81bLkAAAAAElFTkSuQmCC"

/***/ }),

/***/ 122:
/***/ (function(module, exports, __webpack_require__) {

	module.exports = "\n<div class=\"union-wrap\">\n    <section class=\"union-info-wrap\" v-show=\"isInfo\">\n        <p><span class=\"union-info\"></span><span class=\"union-info-link\">立即认证</span></p>\n    </section>\n    <section class=\"union-top\">\n        <div class=\"union-user\">\n            <div class=\"user-img\">\n                <img src=\"" + __webpack_require__(120) + "\" alt=\"头像\">\n            </div>\n            <div class=\"user-message\" v-if=\"isLogin\">\n                <p>Hi <span class=\"user-name\">{{passport_username}}</span></p>\n                <p class=\"area\">{{alliance_name}}</p>\n            </div>\n            <div class=\"user-message\" v-else>\n                <p class=\"user-no-login\">未登录</p>\n            </div>\n        </div>\n        <div class=\"union-number\">\n            <ul class=\"commission\">\n                <li class=\"today border-rt\">\n                    <div class=\"today-count\">{{today_commission}}</div>\n                    <p>今日预估佣金</p>\n                </li>\n                <li class=\"total\">\n                    <div class=\"total-count\">{{total_commission}}</div>\n                    <p>累计佣金</p>\n                </li>\n            </ul>\n        </div>\n    </section>\n    <ul class=\"union-list\">\n        <li class=\"my-material\" v-on:click=\"materialClick\"><span class=\"icon icon-material\"></span><p class=\"border-bt\">我的物料</p></li>\n        <li class=\"baiduwallet\" v-on:click=\"baiduWalletclick\"><span class=\"icon icon-baiduwallet\"></span><p class=\"border-bt\">百度钱包</p></li>\n        <li class=\"my-message\" v-on:click=\"myMessageclick\"><span class=\"icon icon-message\"></span><p class=\"border-bt\">我的消息</p></li>\n    </ul>\n</div>\n";

/***/ }),

/***/ 124:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_script__, __vue_template__
	var __vue_styles__ = {}
	__vue_script__ = __webpack_require__(60)
	if (Object.keys(__vue_script__).some(function (key) { return key !== "default" && key !== "__esModule" })) {
	  console.warn("[vue-loader] src\\components\\unionCenter\\index.vue: named exports in *.vue files are ignored.")}
	__vue_template__ = __webpack_require__(122)
	module.exports = __vue_script__ || {}
	if (module.exports.__esModule) module.exports = module.exports.default
	var __vue_options__ = typeof module.exports === "function" ? (module.exports.options || (module.exports.options = {})) : module.exports
	if (__vue_template__) {
	__vue_options__.template = __vue_template__
	}
	if (!__vue_options__.computed) __vue_options__.computed = {}
	Object.keys(__vue_styles__).forEach(function (key) {
	var module = __vue_styles__[key]
	__vue_options__.computed[key] = function () { return module }
	})
	if (false) {(function () {  module.hot.accept()
	  var hotAPI = require("vue-hot-reload-api")
	  hotAPI.install(require("vue"), false)
	  if (!hotAPI.compatible) return
	  var id = "_v-72109878/index.vue"
	  if (!module.hot.data) {
	    hotAPI.createRecord(id, module.exports)
	  } else {
	    hotAPI.update(id, module.exports, __vue_template__)
	  }
	})()}

/***/ })

});