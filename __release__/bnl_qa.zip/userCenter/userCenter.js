webpackJsonp([7],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _vue = __webpack_require__(13);

	var _vue2 = _interopRequireDefault(_vue);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var $ = __webpack_require__(2);
	__webpack_require__(58);
	var api = __webpack_require__(3);
	var util = __webpack_require__(1);

	var Promise = __webpack_require__(42).Promise;
	var dialog = __webpack_require__(14);
	var httpBnjs = __webpack_require__(5);
	var server = __webpack_require__(8).server;
	var LOGIN_URL = encodeURIComponent(server + '/naserver/newapp/merchantlogintpl');
	__webpack_require__(25);
	__webpack_require__(104);
	__webpack_require__(106);

	var vm = new _vue2.default({
	    el: '#app',
	    template: __webpack_require__(117),
	    data: {
	        token: "",
	        passport_username: "--",
	        real_name: "--",
	        mobile: "--",
	        certificate_no: "--",
	        city_name: "--",
	        is_verified: 0,
	        alliance_name: "--"
	    },
	    created: function created() {
	        var _this = this;
	        util.ready(function () {
	            _this.getData();
	        });
	    },
	    watch: function watch() {},
	    methods: {
	        getData: function getData() {
	            var that = this;
	            var uid = BNJS.account.uid || 0;
	            httpBnjs.get({
	                url: api.myuserinfo,
	                params: {
	                    b_uid: uid
	                }
	            }).then(function (res) {
	                that.userInfoOk(res);
	            }, function (res) {
	                BNJS.ui.showErrorPage();
	            });
	        },
	        userInfoOk: function userInfoOk(res) {
	            var that = this;
	            switch (res.errno) {
	                case 0:
	                    {
	                        that.passport_username = res.data.passport_username ? res.data.passport_username : "--";
	                        that.real_name = res.data.real_name ? res.data.real_name : "--";
	                        that.mobile = res.data.mobile ? res.data.mobile : "--";
	                        that.certificate_no = res.data.certificate_no ? res.data.certificate_no : "--";
	                        that.city_name = res.data.city_name ? res.data.city_name : "--";
	                        that.alliance_name = res.data.alliance_name ? res.data.alliance_name : "--";
	                        that.is_verified = res.data.is_verified;
	                        if (that.is_verified === 0) {
	                            $('.user-verified').on('tap', function () {
	                                var url = encodeURIComponent("https://m.baifubao.com/wap/0/wallet/0/cardlist/0");
	                                BNJS.page.start("BaiduNuomiMerchant://component?url=" + url, {});
	                            });
	                        }
	                        break;
	                    }
	                case 2002:
	                    var url = 'BaiduNuomiMerchant://component?compid=bnl&comppage=unionCenter';
	                    BNJS.page.start(url, {}, 1);
	                    break;
	                default:
	                    BNJS.ui.showErrorPage();
	            }
	        },
	        loginClick: function loginClick() {
	            $.dialog({
	                type: 'confirm',
	                showTitle: false,
	                dialogClass: 'addUnion',
	                contentHtml: "您真的想要退出登录嘛！",
	                buttonText: {
	                    ok: '重新登录',
	                    cancel: '稍后再说'
	                },
	                buttonClass: {
	                    ok: 'dialog-font-color-blue',
	                    cancel: 'dialog-btn-cancel'
	                },
	                onClickOk: function onClickOk() {
	                    var url = 'BaiduNuomiMerchant://component?url=' + LOGIN_URL;
	                    BNJS.localStorage.setItem('bnl_bduss', 'invalid', function () {
	                        BNJS.page.start(url, {});
	                    }, function (res) {});
	                },
	                onClickCancel: function onClickCancel() {}
	            });
	        }
	    },
	    components: {}
	});

	util.ready(function () {
	    BNJS.ui.hideLoadingPage();
	    BNJS.ui.title.setTitle('个人资料');
	    BNJS.page.reShow(function () {
	        BNJS.page.start('BaiduNuomiMerchant://component?compid=bnl&comppage=userCenter', {});
	    });
	});

/***/ }),

/***/ 104:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 106:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 117:
/***/ (function(module, exports) {

	module.exports = "<div>\n    <div class=\"user-wrap\">\n        <ul class=\"user-list\">\n            <li class=\"user-item border-bt\"><strong>百度账号</strong><span>{{passport_username}}</span></li>\n            <li class=\"user-item border-bt\" v-if=\"is_verified\"><strong>姓名</strong><span>{{real_name}}</span><span class=\"user-verified\">已认证</span><em class=\"user-ok\"></em></li>\n            <li class=\"user-item border-bt\" v-else><strong>姓名</strong><span>{{real_name}}</span><span class=\"user-verified\">未认证，去认证</span><em class=\"user-error\"></em></li>\n            <li class=\"user-item border-bt\"><strong>手机号</strong><span>{{mobile}}</span></li>\n            <li class=\"user-item border-bt\"><strong>证件号</strong><span>{{certificate_no}}</span></li>\n            <li class=\"user-item border-bt\"><strong>推广区域</strong><span>{{city_name}}</span></li>\n            <li class=\"user-item border-bt\"><strong>推广联盟</strong><span>{{alliance_name}}</span></li>\n        </ul>\n    </div>\n    <div class=\"user-login bd-radius ratina-bd\">\n        <button type=\"button\" class=\"\" v-on:tap=\"loginClick\">退出登录</button>\n    </div>\n</div>"

/***/ })

});