webpackJsonp([8],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _myMaterial = __webpack_require__(100);

	var _myMaterial2 = _interopRequireDefault(_myMaterial);

	var _vue = __webpack_require__(13);

	var _vue2 = _interopRequireDefault(_vue);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var $ = __webpack_require__(2);
	var api = __webpack_require__(3);
	var util = __webpack_require__(1);
	var utilBNJS = __webpack_require__(15);
	var httpBnjs = __webpack_require__(5);
	var Baidu = __webpack_require__(16);
	var Promise = __webpack_require__(42).Promise;
	var dialog = __webpack_require__(14);
	var FastClick = __webpack_require__(39);

	var server = __webpack_require__(8).server;
	var merchantlogin = encodeURIComponent(server + '/naserver/newapp/merchantlogintpl');
	var accessParam = {};

	var material_button = $('.claim-button');

	var dialogTpl = __webpack_require__(111);

	var tpl = __webpack_require__(112);

	FastClick.attach(document.body, {});

	var materialItemView = {
	    pageData: {},
	    init: function init() {
	        var me = this;
	        me.load();
	        $(document).on('click', '.material-item-link', function (e) {
	            var data_id = $(this).data('id');
	            var params = {
	                id: data_id
	            };
	            console.log("物料上的id" + data_id);
	            BNJS.page.start('BaiduNuomiMerchant://component?compid=bnl&comppage=cardList', params);
	        });
	    },
	    load: function load() {
	        var me = this;
	        httpBnjs.get({
	            url: api.codelist,
	            params: {}
	        }).then(function (res) {
	            var data = res;

	            if (data.errno != 0) {
	                if (resp.errno === 2002) {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: resp.msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        },
	                        onClickOk: function onClickOk() {
	                            BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	                        }
	                    });
	                } else {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: data.msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        }
	                    });
	                }
	            } else {
	                me.render(data.data.list);
	            }
	        }, function (res) {
	            BNJS.ui.showErrorPage();
	        });
	    },
	    render: function render(list) {
	        var HTML = Baidu.template(tpl, {
	            item: list
	        });
	        $('section').html(HTML);
	    }
	};

	var bindButton = {
	    init: function init() {
	        var _this = this;
	        material_button.on('tap', function (ev) {
	            httpBnjs.get({
	                url: api.memberMerchant,
	                params: {}
	            }).then(function (resp) {
	                if (resp.data.alliance_name) {
	                    var res = resp.data;
	                    var html = Baidu.template(dialogTpl, {
	                        title: '是否绑定此门店?',
	                        name: res.alliance_name,
	                        id: res.merchant_id
	                    });

	                    $.dialog({
	                        type: 'confirm',
	                        showTitle: false,
	                        contentHtml: html,
	                        buttonText: {
	                            ok: '立即绑定',
	                            cancel: '换门店绑定'
	                        },
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink',
	                            cancel: 'dialog-btn-cancel'
	                        },
	                        res: res,
	                        onClickOk: function onClickOk() {
	                            _this.bindMaterial(res.merchant_id);
	                        },
	                        onClickCancel: function onClickCancel() {
	                            BNJS.page.start("BaiduNuomiMerchant://component?compid=bnl&comppage=mendianSearch", {});
	                        }
	                    });
	                }
	            }, function (res) {
	                BNJS.page.start("BaiduNuomiMerchant://component?compid=bnl&comppage=mendianSearch", {}, 1);
	            });
	        });
	    },
	    bindMaterial: function bindMaterial(merchant_id) {
	        var _this = this;
	        util.ready(function () {
	            BNJS.hardware.scanQRCode(function (res) {
	                var url = res.data.content;
	                var result = util.parseQueryString(url);
	                var code_id = result.id;
	                httpBnjs.post({
	                    url: api.bindcode,
	                    params: {
	                        code_id: code_id,
	                        product: 5,
	                        merchant_id: merchant_id
	                    }
	                }).then(function (resp) {
	                    if (resp.errno === 2002) {
	                        $.dialog({
	                            showTitle: false,
	                            contentHtml: resp.msg,
	                            buttonClass: {
	                                ok: 'dialog-font-color-pink'
	                            },
	                            onClickOk: function onClickOk() {
	                                BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	                            }
	                        });
	                    } else if (resp.errno === 0) {
	                        $.dialog({
	                            showTitle: false,
	                            contentHtml: "认领成功",
	                            buttonClass: {
	                                ok: 'dialog-font-color-pink'
	                            },
	                            onClickOk: function onClickOk() {
	                                BNJS.page.start("BaiduNuomiMerchant://component?compid=bnl&comppage=myMaterial", {}, 1);
	                            }
	                        });
	                    } else {
	                        $.dialog({
	                            showTitle: false,
	                            contentHtml: resp.msg,
	                            buttonClass: {
	                                ok: 'dialog-font-color-pink'
	                            },
	                            onClickOk: function onClickOk() {
	                                BNJS.page.start("BaiduNuomiMerchant://component?compid=bnl&comppage=myMaterial", {}, 1);
	                            }
	                        });
	                    }
	                }, function (res) {});
	            });
	        });
	    }
	};

	var init = function init() {
	    materialItemView.init();
	    bindButton.init();
	};

	util.ready(function () {
	    BNJS.ui.hideLoadingPage();
	    BNJS.ui.title.setTitle('我的物料');
	    init();
	    BNJS.page.reShow(function () {
	        init();
	    });
	});

/***/ }),

/***/ 100:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 111:
/***/ (function(module, exports) {

	module.exports = "<div class=\"dialog-close\"></div>\r\n<div class=\"title\"><%=title%></div>\r\n<div class=\"title-h1\"><%=name%></div>\r\n<div class=\"title-h1\">门店ID:<%=id%></div>"

/***/ }),

/***/ 112:
/***/ (function(module, exports) {

	module.exports = "<%if(item.length){%>\r\n<%for(var i=0; i<item.length;i++){%>\r\n<a href=\"javascript:void(0);\" data-id=\"<%=item[i].id%>\" class=\"material-item-link\">\r\n<div class=\"material-item\">\r\n\t\t<span>物料ID:<%=item[i].id%></span>   \r\n\t\t<span class='arrow-right'></span>       \r\n</div>\r\n</a>\r\n<%}%>\r\n<%}%>"

/***/ })

});