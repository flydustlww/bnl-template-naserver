webpackJsonp([7],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _myMaterial = __webpack_require__(104);

	var _myMaterial2 = _interopRequireDefault(_myMaterial);

	var _vue = __webpack_require__(14);

	var _vue2 = _interopRequireDefault(_vue);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var $ = __webpack_require__(2);
	var api = __webpack_require__(4);
	var util = __webpack_require__(1);
	var utilBNJS = __webpack_require__(3);
	var httpBnjs = __webpack_require__(6);
	var Baidu = __webpack_require__(16);
	var Promise = __webpack_require__(17).Promise;
	var dialog = __webpack_require__(9);
	var FastClick = __webpack_require__(41);

	var server = __webpack_require__(15).server;
	var merchantlogin = encodeURIComponent(server + '/naserver/newapp/merchantlogintpl');
	var accessParam = {};

	var material_button = $('.claim-button');

	var dialogTpl = __webpack_require__(116);

	var tpl = __webpack_require__(117);

	FastClick.attach(document.body, {});

	var materialItemView = {
	    pageData: {},
	    init: function init() {
	        var me = this;
	        me.load();
	        $(document).on('click', '.material-item-link', function (e) {
	            var id = $(this).data('id');
	            BNJS.page.start('BaiduNuomiMerchant://component?compid=bnl&comppage=cardList', { id: id });
	        });
	    },
	    load: function load() {
	        var me = this;
	        httpBnjs.get({
	            url: api.codelist,
	            params: {}
	        }).then(function (res) {
	            var data = res;

	            if (data.errno != 0) {
	                if (resp.errno === 2002) {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: resp.msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        },
	                        onClickOk: function onClickOk() {
	                            BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	                        }
	                    });
	                } else {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: data.msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        }
	                    });
	                }
	            } else {
	                me.render(data.data.list);
	            }
	        }, function (res) {
	            BNJS.ui.showErrorPage();
	        });
	    },
	    render: function render(list) {
	        var HTML = Baidu.template(tpl, {
	            item: list
	        });
	        $('section').html(HTML);
	    }
	};

	var bindButton = {
	    init: function init() {
	        var _this = this;
	        material_button.on('tap', function (ev) {
	            httpBnjs.get({
	                url: api.memberMerchant,
	                params: {}
	            }).then(function (resp) {
	                if (resp.data.alliance_name) {
	                    var res = resp.data;
	                    var html = Baidu.template(dialogTpl, {
	                        title: '是否绑定此门店?',
	                        name: res.alliance_name,
	                        id: res.merchant_id
	                    });

	                    $.dialog({
	                        type: 'confirm',
	                        showTitle: false,
	                        contentHtml: html,
	                        buttonText: {
	                            ok: '立即绑定',
	                            cancel: '换门店绑定'
	                        },
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink',
	                            cancel: 'dialog-btn-cancel'
	                        },
	                        res: res,
	                        onClickOk: function onClickOk() {
	                            _this.bindMaterial();
	                        },
	                        onClickCancel: function onClickCancel() {
	                            BNJS.page.start("BaiduNuomiMerchant://component?compid=bnl&comppage=mendianSearch", {}, 1);
	                        }
	                    });
	                }
	            }, function (res) {
	                BNJS.page.start("BaiduNuomiMerchant://component?compid=bnl&comppage=mendianSearch", {}, 1);
	            });
	        });
	    },
	    bindMaterial: function bindMaterial() {
	        var _this = this;
	        util.ready(function () {
	            BNJS.hardware.scanQRCode(function (res) {
	                var url = res.data.content;
	                var result = util.parseQueryString(url);
	                var code_id = result.id;
	                httpBnjs.get({
	                    url: api.bindcode,
	                    params: {
	                        code_id: code_id,
	                        product: 5
	                    }
	                }).then(function (resp) {
	                    if (resp.errno === 2002) {
	                        $.dialog({
	                            showTitle: false,
	                            contentHtml: resp.msg,
	                            buttonClass: {
	                                ok: 'dialog-font-color-pink'
	                            },
	                            onClickOk: function onClickOk() {
	                                BNJS.page.start("BaiduNuomiMerchant://component?url=" + merchantlogin, {}, 1);
	                            }
	                        });
	                    } else {
	                        $.dialog({
	                            showTitle: false,
	                            contentHtml: resp.msg,
	                            buttonClass: {
	                                ok: 'dialog-font-color-pink'
	                            },
	                            onClickOk: function onClickOk() {}
	                        });
	                    }
	                }, function (res) {});
	            });
	        });
	    }
	};

	var init = function init() {
	    materialItemView.init();
	    bindButton.init();
	};

	util.ready(function () {
	    BNJS.ui.hideLoadingPage();
	    BNJS.ui.title.setTitle('我的物料');
	    init();
	});

/***/ }),

/***/ 104:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 116:
/***/ (function(module, exports) {

	module.exports = "<div class=\"dialog-close\"></div>\r\n<div class=\"title\"><%=title%></div>\r\n<div class=\"title-h1\"><%=name%></div>\r\n<div class=\"title-h1\">门店ID:<%=id%></div>"

/***/ }),

/***/ 117:
/***/ (function(module, exports) {

	module.exports = "<%if(item.length){%>\r\n<%for(var i=0; i<item.length;i++){%>\r\n<a href=\"javascript:void(0);\" data-id=\"<%=item[i].id%>\" class=\"material-item-link\">\r\n<div class=\"material-item\">\r\n\t\t<span>物料ID:<%=item[i].id%></span>   \r\n\t\t<span class='arrow-right'></span>       \r\n</div>\r\n</a>\r\n<%}%>\r\n<%}%>"

/***/ })

});