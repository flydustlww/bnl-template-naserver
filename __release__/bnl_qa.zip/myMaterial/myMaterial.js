webpackJsonp([8],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _myMaterial = __webpack_require__(99);

	var _myMaterial2 = _interopRequireDefault(_myMaterial);

	var _vue = __webpack_require__(12);

	var _vue2 = _interopRequireDefault(_vue);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var $ = __webpack_require__(1);
	var api = __webpack_require__(4);
	var util = __webpack_require__(2);
	var utilBNJS = __webpack_require__(3);
	var httpBnjs = __webpack_require__(15);
	var Baidu = __webpack_require__(14);
	var Promise = __webpack_require__(23).Promise;
	var dialog = __webpack_require__(13);

	var accessParam = {};

	var material_button = $('.claim-button');

	var dialogTpl = __webpack_require__(110);

	var tpl = __webpack_require__(111);

	var materialItemView = {
	    pageData: {},
	    init: function init() {
	        var me = this;
	        me.load();
	    },
	    load: function load() {
	        var me = this;
	        accessParam.bduss = bdussStroage;
	        httpBnjs.get({
	            url: api.codelist,
	            params: {
	                b_uid: uid,
	                bduss: bdussStroage
	            }
	        }).then(function (res) {
	            var data = res;

	            if (data.errno != 0) {
	                if (resp.errno === 2002) {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: resp.msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        },
	                        onClickOk: function onClickOk() {
	                            BNJS.page.start('BaiduNuomiMerchant://component?url=http://cp01-ocean-1115-offline.epc.baidu.com:8080/naserver/newapp/merchantlogintpl', {});
	                        }
	                    });
	                } else {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: data.msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        }
	                    });
	                }
	            } else {
	                me.render(data.data.list);
	            }
	        }, function (res) {
	            BNJS.ui.showErrorPage();
	        });
	    },
	    render: function render(list) {
	        var HTML = Baidu.template(tpl, {
	            item: list,
	            url: 'cardList.html?'
	        });
	        $('section').html(HTML);
	    }
	};

	var bindButton = {
	    init: function init() {
	        var _this = this;
	        material_button.on('tap', function (ev) {
	            httpBnjs.get({
	                url: api.memberMerchant,
	                params: {
	                    b_uid: uid,
	                    bduss: bdussStroage
	                }
	            }).then(function (resp) {
	                var html = Baidu.template(dialogTpl, {
	                    title: '是否绑定此门店?',
	                    name: res.alliance_name,
	                    id: res.merchant_id
	                });
	                if (resp.data.alliance_name) {
	                    var _res = resp.data;

	                    $.dialog({
	                        type: 'confirm',
	                        showTitle: false,
	                        contentHtml: html,
	                        buttonText: {
	                            ok: '立即绑定',
	                            cancel: '换门店绑定'
	                        },
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink',
	                            cancel: 'dialog-btn-cancel'
	                        },
	                        res: _res,
	                        onClickOk: function onClickOk() {
	                            _this.bindMaterial();
	                        },
	                        onClickCancel: function onClickCancel() {
	                            BNJS.page.start("BaiduNuomiMerchant://component?compid=bnl&comppage=mendianSearch", {}, 1);
	                        }
	                    });
	                }
	            }, function (res) {
	                BNJS.page.start("BaiduNuomiMerchant://component?compid=bnl&comppage=mendianSearch", {}, 1);
	            });
	        });
	    },
	    bindMaterial: function bindMaterial() {
	        var _this = this;
	        util.ready(function () {
	            BNJS.hardware.scanQRCode(function (res) {
	                var url = res.data.content;
	                var result = util.parseQueryString(url);
	                var code_id = result.id;
	                httpBnjs.get({
	                    url: api.bindcode,
	                    params: {
	                        b_uid: uid,
	                        bduss: bdussStroage,
	                        code_id: code_id,
	                        product: 5
	                    }
	                }).then(function (resp) {
	                    if (resp.errno === 2002) {
	                        $.dialog({
	                            showTitle: false,
	                            contentHtml: resp.msg,
	                            buttonClass: {
	                                ok: 'dialog-font-color-pink'
	                            },
	                            onClickOk: function onClickOk() {
	                                BNJS.page.start("BaiduNuomiMerchant://component?url=http://cp01-ocean-1115-offline.epc.baidu.com:8080/naserver/newapp/merchantlogintpl", {});
	                            }
	                        });
	                    } else {
	                        $.dialog({
	                            showTitle: false,
	                            contentHtml: resp.msg,
	                            buttonClass: {
	                                ok: 'dialog-font-color-pink'
	                            },
	                            onClickOk: function onClickOk() {}
	                        });
	                    }
	                }, function (res) {});
	            });
	        });
	    }
	};

	var init = function init() {
	    materialItemView.init();
	    bindButton.init();
	};

	util.ready(function () {
	    BNJS.ui.hideLoadingPage();
	    init();
	    BNJS.ui.title.setTitle('我的物料');
	});

/***/ }),

/***/ 99:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 110:
/***/ (function(module, exports) {

	module.exports = "<div class=\"dialog-close\"></div>\n<div class=\"title\"><%=title%></div>\n<div class=\"title-h1\"><%=name%></div>\n<div class=\"title-h1\">门店ID:<%=id%></div>"

/***/ }),

/***/ 111:
/***/ (function(module, exports) {

	module.exports = "<%if(item.length){%>\n<%for(var i=0; i<item.length;i++){%>\n<a href=\"<%=url%>&id=<%=item[i].id%>\">\n<div class=\"material-item\">\n\t\t<span>物料ID:<%=item[i].id%></span>   \n\t\t<span class='arrow-right'></span>       \n</div>\n</a>\n<%}%>\n<%}%>"

/***/ })

});