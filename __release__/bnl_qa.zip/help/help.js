webpackJsonp([10],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	__webpack_require__(25);
	__webpack_require__(98);
	var utilBNJS = __webpack_require__(15);
	var $ = __webpack_require__(2);
	var util = __webpack_require__(1);

	util.ready(function () {
	  BNJS.ui.hideLoadingPage();
	  BNJS.ui.title.setTitle('百度糯米商户联盟');
	});

/***/ }),

/***/ 98:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ })

});