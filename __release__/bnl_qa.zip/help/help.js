webpackJsonp([11],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	__webpack_require__(23);
	__webpack_require__(99);
	var utilBNJS = __webpack_require__(3);
	var $ = __webpack_require__(1);
	var util = __webpack_require__(2);

	util.ready(function () {
	  BNJS.ui.hideLoadingPage();
	  BNJS.ui.title.setTitle('百度糯米商户联盟');
	});

/***/ }),

/***/ 99:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ })

});