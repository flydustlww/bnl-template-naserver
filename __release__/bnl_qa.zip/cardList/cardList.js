webpackJsonp([9],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _vue = __webpack_require__(12);

	var _vue2 = _interopRequireDefault(_vue);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	__webpack_require__(51);
	__webpack_require__(52);
	__webpack_require__(93);

	var $ = __webpack_require__(1);
	var api = __webpack_require__(4);


	var util = __webpack_require__(2);
	var urlParam = __webpack_require__(39);
	__webpack_require__(54);
	var dialog = __webpack_require__(13);
	var radiogroup = __webpack_require__(129).RadioGroup;

	var curUid = urlParam.getUrlParam('uid');
	var curSid = urlParam.getUrlParam('sid');
	var app_version = urlParam.getUrlParam('app_version');
	var id = urlParam.getUrlParam('id');
	var location = urlParam.getUrlParam('location');
	var unbindDialogHtml = '<p >确认解除物料与您的绑定关系？解绑后，将无法获得推广佣金！</p>';
	var bindDialogHtml = '<p class="dialog-item"><label>类型：</label><input type="radio" id="radio-1" name="product-radio" class="regular-radio" checked value="0"/><label for="radio-1"></label>普通' + '<input type="radio" id="radio-2" name="product-radio" class="regular-radio" value="1"/><label for="radio-2" ></label>到店付' + '<input type="radio" id="radio-3" name="product-radio" class="regular-radio" value="4"/><label for="radio-3"></label>储值卡' + '<p class="dialog-item"><label>团单ID：</label><input type="number" class="deal-id-text" placeholder="团单ID"></p>' + '<p class="dialog-item dialog-merchant-item"><label>门店ID：</label><input type="number" class="merchant-id-text" placeholder="门店ID"></p>';
	var isAjaxLocked = false;
	var totalDom = void 0;
	var codeListDom = void 0;
	var addCodeBtn = void 0;
	var radioObj = void 0;
	var curProduct = void 0;
	var curId = void 0;
	var getCodeList = function getCodeList(uid, sid, app_version, location, id) {
	    var param = {
	        uid: uid,
	        sid: sid,
	        app_version: app_version,
	        location: location,
	        id: id
	    };
	    if (!isAjaxLocked) {
	        isAjaxLocked = true;
	        $.ajax({
	            url: api.codelist,
	            type: 'GET',
	            dataType: 'json',
	            data: param,
	            success: function success(data) {
	                isAjaxLocked = false;
	                if (data.errno != 0) {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: data.msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        }
	                    });
	                    return;
	                } else {
	                    if (data.data.count != 0) {
	                        $.each(data.data.list, function (i, item) {
	                            if (item.deal_info == '') {
	                                item.deal_info = '--';
	                            }

	                            if (item.materiel_info == '') {
	                                item.materiel_info = '--';
	                            }
	                        });
	                        var html = template('codeList-item-tpl', data.data);
	                        $(html).prependTo($('#codeList'));
	                        $('.loadingmore').show();
	                    } else {
	                        var _html = template('none-list-tpl', {});
	                        $('#codeList').html(_html);
	                    }
	                }
	            }
	        });
	    }
	};

	var unbindCode = function unbindCode(uid, sid, id) {
	    var param = {
	        uid: uid,
	        sid: sid,
	        code_id: id
	    };
	    $.ajax({
	        url: '/naserver/common/unbindcode',
	        type: 'POST',
	        dataType: 'json',
	        data: param,
	        success: function success(data) {
	            if (data.errno != 0) {
	                var msg = data.msg;
	                setTimeout(function (data) {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        },
	                        onClickOk: function onClickOk() {
	                            $('.solve-tap-bug').remove();
	                        }
	                    });
	                }, 200);
	                return;
	            } else {
	                window.location.reload();
	            }
	        }
	    });
	};

	var bindCode = function bindCode(app_version, location, uid, sid, id, deal_id, merchant_id, product) {
	    var param = {
	        app_version: app_version,
	        location: location,
	        uid: uid,
	        sid: sid,
	        code_id: id,
	        deal_id: deal_id,
	        merchant_id: merchant_id,

	        product: product
	    };
	    $.ajax({
	        url: api.bindcode,
	        type: 'POST',
	        dataType: 'json',
	        data: param,
	        success: function success(data) {
	            if (data.errno != 0) {
	                var msg = data.msg;
	                setTimeout(function (data) {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        },
	                        onClickOk: function onClickOk() {
	                            $('.solve-tap-bug').remove();
	                        }
	                    });
	                }, 200);
	                return;
	            } else {
	                window.location.reload();
	            }
	        }
	    });
	};

	var showUnbindDialog = function showUnbindDialog() {
	    $.dialog({
	        type: 'confirm',
	        showTitle: false,
	        contentHtml: unbindDialogHtml,
	        buttonClass: {
	            ok: 'dialog-font-color-pink',
	            cancel: 'dialog-font-color-pink'
	        },
	        onClickOk: function onClickOk() {
	            unbindCode(curUid, curSid, curId);
	        }
	    });
	};

	var showBindDialog = function showBindDialog() {
	    $.dialog({
	        type: 'confirm',
	        titleText: '物料与团单关系重新绑定',
	        contentHtml: bindDialogHtml,

	        buttonClass: {
	            ok: 'dialog-font-color-pink',
	            cancel: 'dialog-font-color-pink'
	        },
	        onClickOk: function onClickOk() {
	            var curDealId = $('.dialog-wrap').find('.deal-id-text').val();
	            var curMerchantId = $('.dialog-wrap').find('.merchant-id-text').val();

	            curProduct = radioObj.getValue();
	            console.log('bindcode curProduct' + curProduct);
	            bindCode(app_version, location, curUid, curSid, curId, curDealId, curMerchantId, curProduct);
	        },
	        onShow: function onShow() {
	            radioObj = new radiogroup({
	                container: $('.dialog-wrap')[0],
	                classname: 'regular-radio'
	            });
	            radioObj.on('valuechange', function () {
	                if (radioObj.getValue() == 1) {
	                    $('.dialog-wrap').find('.dialog-merchant-item').show();
	                } else {
	                    $('.dialog-wrap').find('.dialog-merchant-item').find('.merchant-id-text').val('');
	                    $('.dialog-wrap').find('.dialog-merchant-item').hide();
	                }
	            });
	        }
	    });
	};
	var getDom = function getDom() {
	    totalDom = $('.total-amount ');
	    codeListDom = $('#codeList');
	    addCodeBtn = $('.add-code-btn');
	};
	var bind = function bind() {
	    codeListDom.on('click', function (evt) {
	        var target = $(evt.target);
	        var type = target.attr('type');
	        curId = target.attr('itemid');
	        if (type == 'unbind') {
	            showUnbindDialog();
	        }

	        if (type == 'bind') {
	            showBindDialog();
	        }
	    });
	    addCodeBtn.on('click', function () {
	        var url = window.location.href = 'band://web?type=materials_claim&url=' + window.location.protocol + '//' + window.location.host + '/naserver/user/addcodetpl?uid=' + curUid;
	    });
	};
	var initPlugins = function initPlugins() {
	    getCodeList(curUid, curSid, app_version, location, id);
	};

	var init = function init() {
	    initPlugins();

	    getDom();
	    bind();
	};
	init();

/***/ }),

/***/ 93:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 129:
/***/ (function(module, exports, __webpack_require__) {

	/*radio组件*/
	/**
	 * @file Describe the file
	 * @type {[type]}
	 */
	/* eslint-disable */
	var EventEmitter = __webpack_require__(130).EventEmitter;
	function RadioGroup(config) {

	    var configDefault = {
	        container: '',
	        classname: ''
	    };
	    var param = $.extend({}, configDefault, config);
	    this.$container = $(param.container);
	    this.$radios = this.$container.find('.' + param.classname);
	    this.bind();
	}

	$.extend(RadioGroup.prototype, {

	    /**
	     * 绑定事件
	     */
	    bind: function () {
	        var me = this;
	        this.$container.delegate('[type=radio]', 'change', function () {
	            var oldValue = me.keyValue;
	            var newValue = $(this).val();
	            me.keyValue = newValue;
	            me.trigger('valuechange', {
	                oldValue: oldValue,
	                newValue: newValue
	            });
	        });
	    },

	    /**
	        * 获取单选组当前选中值
	        * @returns {*}
	    */
	    getValue: function () {
	        var val = null;
	        $.each(this.$radios, function (index, radio) {
	            if (radio.checked) {
	                val = radio.getAttribute('value') || radio.value;
	                // 不再继续接下来的循环，jQuery特有，不能返回除false其他值
	                return false;
	            }

	        });
	        this.keyValue = val;
	        return val;
	    }
	});

	// 具有事件分发能力
	EventEmitter.bind(RadioGroup);
	exports.RadioGroup = RadioGroup;
	/* eslint-disable */

/***/ }),

/***/ 130:
/***/ (function(module, exports) {

	/**
	 * @file overview 赋予对象或者类以分发自定义事件的能力。
	 *     用法：EventEmitter.inject(Class);
	 *          EventEmitter.bind(instance);
	 *
	 *          绑定的对象包含两个方法：trigger 和 on
	 *
	 * 
	 */
	/* eslint-disable */
	'use strict';

	var $ = window.Zepto;

	function EventEmitter() {
	}

	/**
	 * 订阅事件
	 * @param {string} eventName
	 * @param {function} handler
	 * @param {*} ctx
	 * @returns {DropBox}
	 */
	function on(eventName, handler, ctx) {
	    if (!this.handlerManager) {
	        this.handlerManager = {};
	    }

	    if (!this.handlerManager[eventName]) {
	        this.handlerManager[eventName] = [];
	    }

	    this.handlerManager[eventName].push({
	        handler: handler,
	        ctx: ctx
	    });
	    return this;
	}

	/**
	 * 触发事件
	 * @param {string} eventName
	 * @param {*} args
	 */
	function trigger(eventName, args) {
	    if (!this.handlerManager) {
	        this.handlerManager = {};
	        return this;
	    }

	    if (!this.handlerManager[eventName]) {
	        return this;
	    }

	    args = Array.prototype.slice.call(arguments, 1);
	    var handles = this.handlerManager[eventName];
	    for (var i = 0; i < handles.length; ++i) {
	        handles[i].handler.apply(handles[i].ctx, args);
	    }
	}

	/**
	 * 给指定的对象添加事件分发能力
	 * @param {*} obj
	 */
	EventEmitter.prototype.inject = function (obj) {
	    obj.on = on;
	    obj.trigger = trigger;
	};

	/**
	 * 给指定的类添加事件分发能力
	 * @param {*} Class
	 */
	EventEmitter.prototype.bind = function (Class) {
	    $.extend(Class.prototype, {
	        on: on,
	        trigger: trigger
	    });
	};

	// 导出
	exports.EventEmitter = new EventEmitter();
	/* eslint-disable */

/***/ })

});