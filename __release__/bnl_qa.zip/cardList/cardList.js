webpackJsonp([12],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _vue = __webpack_require__(15);

	var _vue2 = _interopRequireDefault(_vue);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	__webpack_require__(38);
	__webpack_require__(39);
	__webpack_require__(98);
	var $ = __webpack_require__(2);
	var api = __webpack_require__(4);
	var util = __webpack_require__(1);
	var utilBNJS = __webpack_require__(3);
	var httpBnjs = __webpack_require__(6);
	var urlParam = __webpack_require__(59);
	__webpack_require__(40);
	var dialog = __webpack_require__(9);
	var radiogroup = __webpack_require__(60).RadioGroup;

	var curUid = urlParam.getUrlParam('uid');
	var curSid = urlParam.getUrlParam('sid');
	var app_version = urlParam.getUrlParam('app_version');
	var id = urlParam.getUrlParam('id');
	var location = urlParam.getUrlParam('location');
	var unbindDialogHtml = '<p >确认解除物料与您的绑定关系？解绑后，将无法获得推广佣金！</p>';
	var bindDialogHtml = '<p class="dialog-item"><label>类型：</label><input type="radio" id="radio-1" name="product-radio" class="regular-radio" checked value="0"/><label for="radio-1"></label>普通' + '<input type="radio" id="radio-2" name="product-radio" class="regular-radio" value="1"/><label for="radio-2" ></label>到店付' + '<input type="radio" id="radio-3" name="product-radio" class="regular-radio" value="4"/><label for="radio-3"></label>储值卡' + '<p class="dialog-item"><label>团单ID：</label><input type="number" class="deal-id-text" placeholder="团单ID"></p>' + '<p class="dialog-item dialog-merchant-item"><label>门店ID：</label><input type="number" class="merchant-id-text" placeholder="门店ID"></p>';
	var isAjaxLocked = false;
	var totalDom = void 0;
	var codeListDom = void 0;
	var addCodeBtn = void 0;
	var radioObj = void 0;
	var curProduct = void 0;
	var curId = void 0;

	var init = function init(id) {

	    var b_uid = typeof BNJS.account.uid === "number" ? BNJS.account.uid : 0;

	    var getCodeList = function getCodeList(b_uid, id) {
	        var param = {
	            b_uid: b_uid,
	            code_id: id
	        };

	        if (!isAjaxLocked) {
	            isAjaxLocked = true;
	            httpBnjs.get({
	                url: api.codelist,
	                params: param
	            }).then(function (res) {
	                isAjaxLocked = false;
	                if (data.errno != 0) {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: data.msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        }
	                    });
	                    return;
	                } else {
	                    if (data.data.count != 0) {
	                        $.each(data.data.list, function (i, item) {
	                            if (item.deal_info == '') {
	                                item.deal_info = '--';
	                            }

	                            if (item.materiel_info == '') {
	                                item.materiel_info = '--';
	                            }
	                        });
	                        var html = template('codeList-item-tpl', data.data);
	                        $(html).prependTo($('#codeList'));
	                        $('.loadingmore').show();
	                    } else {
	                        var _html = template('none-list-tpl', {});
	                        $('#codeList').html(_html);
	                    }
	                }
	            }, function (res) {
	                BNJS.ui.showErrorPage();
	            });
	        }
	    };

	    var unbindCode = function unbindCode(id) {
	        var param = {
	            code_id: id
	        };
	        httpBnjs.post({
	            url: api.unbindcode,
	            params: param
	        }).then(function (res) {
	            if (data.errno != 0) {
	                var msg = data.msg;
	                setTimeout(function (data) {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        },
	                        onClickOk: function onClickOk() {
	                            $('.solve-tap-bug').remove();
	                        }
	                    });
	                }, 200);
	                return;
	            } else {
	                window.location.reload();
	            }
	        }, function (res) {
	            BNJS.ui.showErrorPage();
	        });
	    };

	    var bindCode = function bindCode(b_uid, id, deal_id, merchant_id, product) {
	        var param = {
	            b_uid: b_uid,
	            code_id: id,
	            deal_id: deal_id,
	            merchant_id: merchant_id,
	            product: product
	        };
	        httpBnjs.post({
	            url: api.bindcode,
	            params: param
	        }).then(function (res) {
	            if (data.errno != 0) {
	                var msg = data.msg;
	                setTimeout(function (data) {
	                    $.dialog({
	                        showTitle: false,
	                        contentHtml: msg,
	                        buttonClass: {
	                            ok: 'dialog-font-color-pink'
	                        },
	                        onClickOk: function onClickOk() {
	                            $('.solve-tap-bug').remove();
	                        }
	                    });
	                }, 200);
	                return;
	            } else {
	                window.location.reload();
	            }
	        }, function (res) {
	            BNJS.ui.showErrorPage();
	        });
	    };

	    var showUnbindDialog = function showUnbindDialog() {
	        $.dialog({
	            type: 'confirm',
	            showTitle: false,
	            contentHtml: unbindDialogHtml,
	            buttonClass: {
	                ok: 'dialog-font-color-pink',
	                cancel: 'dialog-font-color-pink'
	            },
	            onClickOk: function onClickOk() {
	                unbindCode(curId);
	            }
	        });
	    };

	    var showBindDialog = function showBindDialog() {
	        $.dialog({
	            type: 'confirm',
	            titleText: '物料与团单关系重新绑定',
	            contentHtml: bindDialogHtml,

	            buttonClass: {
	                ok: 'dialog-font-color-pink',
	                cancel: 'dialog-font-color-pink'
	            },
	            onClickOk: function onClickOk() {
	                var curDealId = $('.dialog-wrap').find('.deal-id-text').val();
	                var curMerchantId = $('.dialog-wrap').find('.merchant-id-text').val();

	                curProduct = radioObj.getValue();
	                console.log('bindcode curProduct' + curProduct);
	                bindCode(app_version, location, curUid, curSid, curId, curDealId, curMerchantId, curProduct);
	            },
	            onShow: function onShow() {
	                radioObj = new radiogroup({
	                    container: $('.dialog-wrap')[0],
	                    classname: 'regular-radio'
	                });
	                radioObj.on('valuechange', function () {
	                    if (radioObj.getValue() == 1) {
	                        $('.dialog-wrap').find('.dialog-merchant-item').show();
	                    } else {
	                        $('.dialog-wrap').find('.dialog-merchant-item').find('.merchant-id-text').val('');
	                        $('.dialog-wrap').find('.dialog-merchant-item').hide();
	                    }
	                });
	            }
	        });
	    };
	    var getDom = function getDom() {
	        totalDom = $('.total-amount ');
	        codeListDom = $('#codeList');
	        addCodeBtn = $('.add-code-btn');
	    };
	    var bind = function bind() {
	        codeListDom.on('click', function (evt) {
	            var target = $(evt.target);
	            var type = target.attr('type');
	            curId = target.attr('itemid');
	            if (type == 'unbind') {
	                showUnbindDialog();
	            }

	            if (type == 'bind') {
	                showBindDialog();
	            }
	        });
	        addCodeBtn.on('click', function () {
	            BNJS.page.start('BaiduNuomiMerchant://component?compid=bnl&comppage=addCode', {});
	        });
	    };
	    var initPlugins = function initPlugins(b_uid) {
	        getCodeList(b_uid, id);
	    };
	    initPlugins(b_uid);

	    getDom();
	    bind();
	};

	util.ready(function () {
	    BNJS.ui.hideLoadingPage();
	    BNJS.ui.title.setTitle('物料详情');
	    BNJS.page.getData(function (res) {
	        var id = res.data.id;
	        init(id);
	    }, '2.2');
	});

/***/ }),

/***/ 98:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ })

});