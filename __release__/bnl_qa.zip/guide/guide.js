webpackJsonp([11],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _typeof2 = __webpack_require__(41);

	var _typeof3 = _interopRequireDefault(_typeof2);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	__webpack_require__(97);
	var $ = __webpack_require__(2);
	var server = __webpack_require__(9).server;
	var LOGIN_URL = encodeURIComponent(server + '/naserver/newapp/merchantloginguidetpl');

	var BNJSReady = function BNJSReady(readyCallback) {
	    if (readyCallback && typeof readyCallback == 'function') {
	        if (window.BNJS && (0, _typeof3.default)(window.BNJS) == 'object' && BNJS._isAllReady) {
	            readyCallback();
	        } else {
	            document.addEventListener('BNJSReady', function () {
	                readyCallback();
	            }, false);
	        }
	    }
	};

	var guide = function guide() {
	    var me = this;

	    BNJSReady(function () {
	        me.setTitle();

	        me.bindEvents();
	    });
	};

	guide.prototype.setTitle = function () {
	    BNJS.ui.hideLoadingPage();
	    BNJS.ui.title.setTitle('百度糯米商户联盟');
	    BNJS.ui.title.removeBtnAll();
	};

	guide.prototype.bindEvents = function () {
	    var me = this;

	    $('.right').on('touchend', function (e) {
	        var url = 'BaiduNuomiMerchant://component?url=' + LOGIN_URL;
	        BNJS.page.start(url, {}, 1);
	    });
	};

	new guide();

/***/ }),

/***/ 97:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ })

});