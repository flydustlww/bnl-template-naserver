webpackJsonp([10],{

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	__webpack_require__(115);
	__webpack_require__(38);
	__webpack_require__(39);
	__webpack_require__(97);
	var $ = __webpack_require__(2);
	__webpack_require__(40);
	var api = __webpack_require__(4);
	var util = __webpack_require__(1);
	var utilBNJS = __webpack_require__(3);
	var httpBnjs = __webpack_require__(9);
	var Promise = __webpack_require__(16).Promise;
	var dialog = __webpack_require__(8);
	var radiogroup = __webpack_require__(59).RadioGroup;

	var init = function init() {
	    var curUid = "";
	    var b_uid = typeof BNJS.account.uid === "number" ? BNJS.account.uid : 0;
	    var dealIdText;
	    var merchantIdText;
	    var addCodeBtn;
	    var curProduct = 1;
	    var radioObj;
	    var merchantItem;
	    var isAjaxLocked = false;
	    var checkCode = function checkCode(uid, deal_id, merchantId, product) {
	        var naProduct;
	        if (product == 3 && deal_id == '') {
	            $.dialog({
	                showTitle: false,
	                contentHtml: '您录入的为到店付团单，请录入门店ID！',
	                buttonClass: {
	                    ok: 'dialog-font-color-pink'
	                }
	            });
	            return;
	        }
	        var param = {
	            uid: uid,
	            deal_id: deal_id,
	            merchart_id: merchantId,
	            product: product
	        };
	        if (!isAjaxLocked) {}
	    };
	    var getDom = function getDom() {
	        dealIdText = $('.deal-id-text');
	        merchantIdText = $('.merchant-id-text');
	        addCodeBtn = $('.add-code-btn');
	        merchantItem = $('.merchant-item');
	    };
	    var bind = function bind() {
	        addCodeBtn.on('click', function () {
	            var curDealId = dealIdText.val();
	            var curMerchantId = merchantIdText.val();

	            checkCode(curUid, curDealId, curMerchantId, curProduct);
	        });
	        radioObj.on('valuechange', function () {
	            curProduct = radioObj.getValue();
	            if (radioObj.getValue() == 3) {
	                merchantItem.show();
	            } else {
	                merchantIdText.val('');
	                merchantItem.hide();
	            }
	        });
	    };
	    var initPlugins = function initPlugins() {
	        radioObj = new radiogroup({
	            container: $('.content')[0],
	            classname: 'regular-radio'
	        });
	    };
	    initPlugins();
	    getDom();
	    bind();
	};
	uitl.ready(function () {
	    init();
	});

/***/ }),

/***/ 97:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }),

/***/ 115:
/***/ (function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ })

});